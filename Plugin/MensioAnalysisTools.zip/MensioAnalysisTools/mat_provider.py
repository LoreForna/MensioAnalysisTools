# -*- coding: utf-8 -*-
"""
***************************************************************************
    MensioAnalysisTools (MAT) - Processing Provider
    -----------------------------------------------
    Provider di primo livello "MensioAnalysisTools (MAT)" che raccoglie tutti
    gli algoritmi della suite, organizzati in tre gruppi:
      - Analisi quantitative
      - Statistiche avanzate
      - Analisi dei corsi
    Il gruppo (sottocartella) di ciascun algoritmo e' definito dai metodi
    group()/groupId() della rispettiva classe; il provider e' il contenitore
    radice che li raggruppa sotto "MAT" nel Processing Toolbox.
***************************************************************************
"""

import os

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProcessingProvider

# --- algoritmi: Analisi quantitative -------------------------------------
# Tre moduli definiscono una classe omonima 'Analisi': si importano con alias.
from .mattoni_v2_0 import Analisi as MattoniAnalisi
from .mattoni_senza_campione_v2_0 import AnalisiSenzaCampione as MattoniSenzaCampione
from .componenti_a_secco_v2_0 import Analisi as SeccoAnalisi
from .altri_componenti_v2_0 import Analisi as AltriAnalisi
from .componenti_a_secco_altri_materiali_senza_campione_v2_0 import (
    AnalisiComponentiSeccoAltriMaterialiSenzaCampione as SeccoAltriSenzaCampione,
)

# --- algoritmo: Statistiche avanzate -------------------------------------
from .statistiche_avanzate_pattern_reimpiego import MasonryPatternAnalysis

# --- algoritmo: Analisi dei corsi ----------------------------------------
from .analisi_corsi_paramento import CourseAnalysis


class MensioAnalysisProvider(QgsProcessingProvider):
    """Provider radice della suite MensioAnalysisTools."""

    def id(self):
        # identificativo univoco del provider (usato negli id algoritmo completi)
        return 'mat'

    def name(self):
        # nome mostrato come nodo di primo livello nel Processing Toolbox
        return 'MensioAnalysisTools (MAT)'

    def longName(self):
        return 'MensioAnalysisTools (MAT) - Analisi quantitativa delle murature storiche'

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QgsProcessingProvider.icon(self)

    def loadAlgorithms(self):
        algos = [
            # Analisi quantitative
            MattoniAnalisi(),
            MattoniSenzaCampione(),
            SeccoAnalisi(),
            AltriAnalisi(),
            SeccoAltriSenzaCampione(),
            # Statistiche avanzate
            MasonryPatternAnalysis(),
            # Analisi dei corsi
            CourseAnalysis(),
        ]
        for a in algos:
            self.addAlgorithm(a)
