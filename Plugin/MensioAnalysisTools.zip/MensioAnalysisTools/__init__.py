# -*- coding: utf-8 -*-
"""
MensioAnalysisTools (MAT)
Suite di strumenti QGIS per l'analisi quantitativa delle murature storiche.
"""


def classFactory(iface):
    """Punto di ingresso richiesto da QGIS per caricare il plugin."""
    from .mat_plugin import MensioAnalysisPlugin
    return MensioAnalysisPlugin(iface)
