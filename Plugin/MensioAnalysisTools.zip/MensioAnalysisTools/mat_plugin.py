# -*- coding: utf-8 -*-
"""
***************************************************************************
    MensioAnalysisTools (MAT) - Plugin loader
    -----------------------------------------
    Registra il MensioAnalysisProvider nel framework Processing all'avvio del
    plugin e lo rimuove allo spegnimento.
***************************************************************************
"""

from qgis.core import QgsApplication
from .mat_provider import MensioAnalysisProvider


class MensioAnalysisPlugin:
    """Punto di ingresso del plugin: gestisce il ciclo di vita del provider."""

    def __init__(self, iface=None):
        self.iface = iface
        self.provider = None

    def initProcessing(self):
        self.provider = MensioAnalysisProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        self.initProcessing()

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
